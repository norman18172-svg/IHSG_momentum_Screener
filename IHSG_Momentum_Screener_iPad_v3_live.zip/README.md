# IHSG Momentum Screener V3

Versi V3 memaksa alur Live melalui Vercel serverless proxy dan tidak lagi diam-diam fallback ke data demo.

## Arsitektur
- Frontend: `index.html`
- Proxy: `api/maelyn.js`
- Secret: `MAELYN_API_KEY` di Vercel Environment Variables (Production)
- Endpoint utama: Maelyn IDX Top Mover

## Perilaku Live
Saat halaman dibuka, aplikasi langsung memanggil proxy. Jika berhasil, status berubah menjadi `LIVE` dan kartu diisi data Maelyn. Jika gagal, status menjadi `LIVE ERROR` dan pesan error ditampilkan; data demo tidak digunakan sebagai pengganti.

## Data yang tersedia dari endpoint ini
Harga, perubahan, volume, RSI, trend, MACD signal, high/low 52 minggu.
Foreign flow dan bandar flow belum disediakan oleh endpoint yang digunakan, sehingga tidak boleh dipalsukan.

## Deploy
Upload/commit `index.html` dan folder `api/` ke repository GitHub yang terhubung ke Vercel. Pastikan `MAELYN_API_KEY` tersedia untuk Production.
